using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject obj;
    public float time = 1.0f;

    void Start()
    {
        InvokeRepeating("Spawn", 0, time);
    }

    void Spawn()
    {
        Instantiate(obj, transform.position, transform.rotation);
    }
}
