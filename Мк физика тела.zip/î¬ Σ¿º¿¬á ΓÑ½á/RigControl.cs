using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RigControl : MonoBehaviour
{
    public Animator  Animator;
    public Rigidbody[] AllRig;

    private void Awake()
    {
        for (int i = 0; i < AllRig.Length; i++)
        {
            AllRig[i].isKinematic = true;
        }
        
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)) {
            MakePhysical();
        }
        
    }

    public void MakePhysical()
    {
        Animator.enabled = false;
        for (int i = 0; i < AllRig.Length; i++)
        {
            AllRig[i].isKinematic = false;
        }
    }
}
